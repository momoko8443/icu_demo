var icudb = require('./core/icu.db');
var shortid = require('shortid');

//let clients = icudb.getClients();
//let client = icudb.setClient('探视端',shortid.generate());
let client2 = icudb.removeClient('3WNKMcLMw');
//let clients = icudb.getClients();
//console.log(client);
//console.log(clients);