#!/bin/sh
echo "Deprecated use grunt 'grunt jsdoc:server_lite' instead."